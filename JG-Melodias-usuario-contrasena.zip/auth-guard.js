// Control visual de acceso: evita abrir melodias.html sin iniciar sesión
// desde este navegador. No es una protección de servidor para un sitio estático.
if (sessionStorage.getItem('melodias_acceso') !== 'autorizado') {
  window.location.replace('index.html');
}
const cerrar = document.getElementById('cerrar-sesion');
if (cerrar) {
  cerrar.addEventListener('click', () => {
    sessionStorage.removeItem('melodias_acceso');
    window.location.replace('index.html');
  });
}
