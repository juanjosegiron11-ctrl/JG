// La URL y la clave publicable identifican el proyecto; no son claves administrativas.
window.SUPABASE_URL = "https://hypxybgvxvpwfqflijty.supabase.co";
window.SUPABASE_PUBLISHABLE_KEY = "sb_publishable_x6A2XiGzM9F2Qlk9xwBUvA_UK3HoJJz";
