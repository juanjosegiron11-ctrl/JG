const form = document.getElementById('login-form');
const mensaje = document.getElementById('mensaje');
const boton = document.getElementById('login-button');

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  mensaje.textContent = '';

  const usuario = document.getElementById('usuario').value.trim();
  const contrasena = document.getElementById('contrasena').value;

  boton.disabled = true;
  boton.textContent = 'Verificando...';

  try {
    // La comprobación ocurre en el servidor. No se descargan las contraseñas.
    const respuesta = await fetch(`${window.SUPABASE_URL}/functions/v1/validar-login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'apikey': window.SUPABASE_PUBLISHABLE_KEY
      },
      body: JSON.stringify({ usuario, contrasena })
    });

    const resultado = await respuesta.json().catch(() => ({}));
    if (!respuesta.ok || resultado.autenticado !== true) {
      mensaje.textContent = resultado.error || 'Usuario o contraseña incorrectos.';
      return;
    }

    sessionStorage.setItem('melodias_acceso', 'autorizado');
    window.location.href = 'melodias.html';
  } catch (_error) {
    mensaje.textContent = 'No se pudo conectar. Comprueba la configuración de Supabase e inténtalo de nuevo.';
  } finally {
    boton.disabled = false;
    boton.textContent = 'Iniciar sesión';
  }
});
